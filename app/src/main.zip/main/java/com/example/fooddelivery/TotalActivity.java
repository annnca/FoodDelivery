package com.example.fooddelivery;

public class TotalActivity {
}
